import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { clients as initialClients } from './data/clients';
import SearchBar from './components/SearchBar';
import FilterDropdown from './components/FilterDropdown';
import ClientCard from './components/ClientCard';
import ActionButton from './components/ActionButton';
import EmptyState from './components/EmptyState';
import SkeletonCard from './components/SkeletonCard';
import DashboardLayout from './layout/DashboardLayout';
import Dashboard from './pages/Dashboard';

function ClientsPage() {
  const [clientList, setClientList] = useState(initialClients);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const filteredClients = clientList.filter((client) => {
    const matchesSearch = client.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          client.company?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = selectedFilter === 'All' || client.status === selectedFilter;
    return matchesSearch && matchesFilter;
  });

  const totalBudget = clientList.reduce((acc, curr) => acc + (curr.budget || 0), 0);

  const handleDelete = (id) => {
    setClientList((prev) => prev.filter((c) => c.id !== id));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Clients</h1>
          <p className="text-sm text-slate-400 mt-1">Manage all your freelance clients</p>
        </div>
        
        <ActionButton text="Add Client" icon="+" variant="primary" />
      </header>

      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center gap-4 shadow-lg">
        <div className="p-3 bg-violet-500/10 rounded-xl text-2xl border border-violet-500/20">
          💰
        </div>
        <div>
          <p className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Total Budget</p>
          <p className="text-2xl font-extrabold text-white mt-0.5">
            ₹{totalBudget.toLocaleString('en-IN')}
          </p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-4">
        <div className="w-full sm:flex-1">
          <SearchBar value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
        </div>
        <FilterDropdown value={selectedFilter} onChange={(e) => setSelectedFilter(e.target.value)} />
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <SkeletonCard />
          <SkeletonCard />
          <SkeletonCard />
          <SkeletonCard />
        </div>
      ) : filteredClients.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredClients.map((client) => (
            <ClientCard key={client.id} client={client} onDelete={handleDelete} />
          ))}
        </div>
      ) : (
        <EmptyState />
      )}

    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans">
      <BrowserRouter>
        <DashboardLayout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/clients" element={<ClientsPage />} />
            <Route path="/projects" element={<div className="text-2xl font-bold p-6">📁 Projects Page</div>} />
            <Route path="/invoices" element={<div className="text-2xl font-bold p-6">🧾 Invoices Page</div>} />
            <Route path="/settings" element={<div className="text-2xl font-bold p-6">⚙️ Settings Page</div>} />
            <Route path="/profile" element={<div className="text-2xl font-bold p-6">👤 Profile Page</div>} />
          </Routes>
        </DashboardLayout>
      </BrowserRouter>
    </div>
  );
}