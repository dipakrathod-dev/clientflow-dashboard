import React from 'react';

export default function SkeletonCard() {
  return (
    <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-5 animate-pulse flex flex-col justify-between h-48">
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <div className="h-5 w-32 bg-slate-700 rounded"></div>
          <div className="h-4 w-24 bg-slate-700/60 rounded"></div>
        </div>
        <div className="h-6 w-20 bg-slate-700 rounded-full"></div>
      </div>
      <div className="space-y-2 my-3">
        <div className="h-4 w-full bg-slate-700/50 rounded"></div>
        <div className="h-4 w-2/3 bg-slate-700/50 rounded"></div>
      </div>
      <div className="flex justify-between items-center pt-3 border-t border-slate-700/40">
        <div className="h-5 w-20 bg-slate-700 rounded"></div>
        <div className="flex gap-2">
          <div className="h-8 w-14 bg-slate-700 rounded-lg"></div>
          <div className="h-8 w-16 bg-slate-700 rounded-lg"></div>
        </div>
      </div>
    </div>
  );
}