import React from 'react';

export default function ClientCard({ client, onDelete, onEdit }) {
  const getStatusBadge = (status) => {
    switch (status) {
      case 'Active':
        return 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:shadow-[0_0_12px_rgba(16,185,129,0.5)]';
      case 'Pending':
        return 'bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:shadow-[0_0_12px_rgba(245,158,11,0.5)]';
      case 'Completed':
        return 'bg-blue-500/10 text-blue-400 border border-blue-500/30 hover:shadow-[0_0_12px_rgba(59,130,246,0.5)]';
      default:
        return 'bg-slate-500/10 text-slate-400 border border-slate-500/30';
    }
  };

  return (
    <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-5 shadow-md 
                    transition-all duration-300 hover:scale-[1.02] hover:border-violet-500/40 hover:shadow-violet-500/20 hover:shadow-lg 
                    flex flex-col justify-between">
      <div>
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-lg font-semibold text-white">{client.name}</h3>
            <p className="text-xs text-slate-400">{client.company}</p>
          </div>
          <span className={`px-2.5 py-1 text-xs font-medium rounded-full transition-all duration-300 ${getStatusBadge(client.status)}`}>
            {client.status}
          </span>
        </div>
        <p className="text-sm text-slate-300 mb-4">{client.email}</p>
      </div>

      <div className="flex justify-between items-center pt-3 border-t border-slate-700/50">
        <span className="text-base font-bold text-violet-400">
          ₹{client.budget?.toLocaleString('en-IN')}
        </span>
        <div className="flex gap-2">
          <button
            onClick={() => onEdit(client)}
            className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-700/70 rounded-lg 
                       transition-all duration-200 hover:bg-slate-600 hover:scale-105 active:scale-95"
          >
            Edit
          </button>
          <button
            onClick={() => onDelete(client.id)}
            className="px-3 py-1.5 text-xs font-medium text-red-400 bg-red-500/10 rounded-lg 
                       transition-all duration-200 hover:bg-red-600 hover:text-white hover:scale-105 active:scale-95"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}