import React, { useState } from 'react';

const initialClients = [
  { id: 1, name: 'Alex Johnson', email: 'alex@example.com', status: 'Active' },
  { id: 2, name: 'Sarah Connor', email: 'sarah@example.com', status: 'Pending' },
  { id: 3, name: 'Charlie Brown', email: 'charlie@example.com', status: 'Completed' },
  { id: 4, name: 'Diana Prince', email: 'diana@example.com', status: 'Active' },
];

export default function Clients() {
  const [clients, setClients] = useState(initialClients);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  const handleDelete = (id) => {
    setClients(clients.filter((client) => client.id !== id));
  };

  const filteredClients = clients.filter((client) => {
    const matchesSearch = client.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchesStatus =
      statusFilter === 'All' || client.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-5 rounded-xl border border-gray-100 shadow-sm gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Clients</h1>
          <p className="text-sm text-gray-500">Manage all your freelance clients</p>
        </div>
        <div className="bg-gray-100 px-4 py-2 rounded-lg font-semibold text-gray-700 text-sm">
          {clients.length} Clients
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 justify-between items-center">
        <input
          type="text"
          placeholder="Search clients..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full md:w-1/2 px-4 py-2.5 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300"
        />

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="w-full md:w-1/4 px-4 py-2.5 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300 bg-white"
        >
          <option value="All">All</option>
          <option value="Active">Active</option>
          <option value="Pending">Pending</option>
          <option value="Completed">Completed</option>
        </select>
      </div>

      {filteredClients.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed border-gray-200 rounded-2xl bg-gray-50">
          <p className="text-4xl mb-3">📫</p>
          <h3 className="text-lg font-semibold text-gray-800">
            No Clients Found
          </h3>
          <p className="text-sm text-gray-500 mt-1">
            Try another search keyword.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredClients.map((client) => (
            <div
              key={client.id}
              className="p-5 border rounded-2xl shadow-sm bg-white transition duration-300 hover:-translate-y-1 hover:shadow-md flex justify-between items-center"
            >
              <div>
                <h3 className="text-lg font-bold text-gray-800">{client.name}</h3>
                <p className="text-sm text-gray-500">{client.email}</p>
                <span
                  className={`inline-block mt-2 px-2.5 py-0.5 text-xs font-medium rounded-full ${
                    client.status === 'Active'
                      ? 'bg-green-100 text-green-700'
                      : client.status === 'Pending'
                      ? 'bg-yellow-100 text-yellow-700'
                      : 'bg-blue-100 text-blue-700'
                  }`}
                >
                  {client.status}
                </span>
              </div>

              <button
                onClick={() => handleDelete(client.id)}
                className="px-3 py-1.5 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600 transition duration-200 transform hover:scale-105"
              >
                Delete
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}